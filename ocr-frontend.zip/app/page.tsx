import { OCRDashboard } from "@/components/ocr-dashboard"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <OCRDashboard />
    </main>
  )
}
